# truyenkieu-word2vec

Checkout blog detail: http://blog.duyet.net/2017/04/nlp-truyen-kieu-word2vec.html

Word2vec for Truyen Kieu

![](screenshot.png)
